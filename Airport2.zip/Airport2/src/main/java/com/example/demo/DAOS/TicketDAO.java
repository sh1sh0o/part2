package com.example.demo.DAOS;

import com.example.demo.POCOS.*;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
/**
 * This class is being use for interfacing with the "Tickets" table in the database
 */
public class TicketDAO implements DAO<TicketPOCO>{
    private PostgresqlConnection connection = new PostgresqlConnection();
    private ArrayList<TicketPOCO> list = new ArrayList<>();
    private String db = "AirPortDB";
    private Connection con = connection.getConnection(db,"791988ss");
    private Statement statement = connection.getStatement();



    @Override
    public Object Get(long id) {
        TicketPOCO poco = new TicketPOCO();
        try {
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Tickets\"\n" +
                    "where \"Tickets\".\"Id\"=" + id);
            poco.setId(result.getLong("Id"));
            poco.setFlight_Id(result.getLong("Flight_Id"));
            poco.setCustomer_Id(result.getLong("Customer_Id"));
            result.close();
        } catch (Exception e) {

        }

        return poco;
    }

    @Override
    public ArrayList<TicketPOCO> GetAll() {
        try {
            list.clear();
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Tickets\"");
            while (result.next()) {
                TicketPOCO p1 = new TicketPOCO(result.getLong("Id"), result.getLong("Flight_Id")
                        ,result.getLong("Customer_Id"));
                list.add(p1);
            }
            result.close();
        } catch (Exception e) {

        }

        return list;
    }

    /**
     * Adds a ticket
     * @param o The added ticket
     */
    @Override
    public boolean Add(TicketPOCO o) {
        if(Get(o.getFlight_Id())==null)
            return false;

        try {
            var result = statement.executeUpdate("insert into \"Tickets\"(\"Flight_Id\",\"Customer_Id\")\n" +
                    "values(\n" +
                    o.getFlight_Id()+","+
                    o.getCustomer_Id()+
                    "\t\n" +
                    ")");
            return true;
        } catch (Exception e) {
            System.out.println("error- add ticket");
            return false;
        }
    }

    @Override
    public void Remove(TicketPOCO o) {
        if(o==null)
            return;
        if(Get(o.getFlight_Id())==null)
            return;
        try {
            var result = statement.executeUpdate("delete  from \"Tickets\"\n" +
                    "where \"Id\"=" + o.getId());

        } catch (Exception e) {
            System.out.println("error-remove ticket");
        }
    }

    @Override
    public void Update(TicketPOCO o) {
        if(o==null)
            return;
        try {
            var result = statement.executeUpdate("UPDATE \"Tickets\"\n" +
                    "SET  \"Flight_Id\" =" + o.getFlight_Id()  +
                    ", \"Customer_Id\" =" + o.getCustomer_Id() +
                    "where \"Id\"=" + o.getId());

        } catch (Exception e) {

        }
    }

    /**
     * Returns a ticket POCO list of a customer.
     * @param customer_id The customer's id.
     * @return a ticket POCO list of a customer.
     */
    public ArrayList<TicketPOCO> get_tickets_by_customer(long customer_id){
        ArrayList<TicketPOCO> list1=new ArrayList<>();
        try {
            var result=statement.executeQuery("select * from \"get_tickets_by_customer\"("+customer_id+")");
            while (result.next()){
                TicketPOCO poco=new TicketPOCO();
                poco.setId(result.getLong("Id"));
                poco.setFlight_Id(result.getLong("Flight_Id"));
                poco.setCustomer_Id(result.getLong("Customer_Id"));
                list1.add(poco);
            }
            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list1;
    }
}
