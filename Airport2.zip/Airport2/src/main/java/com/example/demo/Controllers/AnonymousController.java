package com.example.demo.Controllers;

import com.example.demo.FACEADES.AnonymousFacade;
import com.example.demo.FACEADES.FacadeBase;
import com.example.demo.POCOS.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.ArrayList;

@RestController
@RequestMapping("/")
public class AnonymousController {


    @PostMapping("/create_new_user")
    public UserPOCO create_new_user(@RequestBody UserPOCO userPOCO) {
        FacadeBase facadeBase=new AnonymousFacade();
        return facadeBase.create_new_user(userPOCO);
    }


    @GetMapping("/get_country_by_id{id}")
    public CountryPOCO get_country_by_id(@PathVariable int _id) {
        FacadeBase facadeBase=new AnonymousFacade();
        return facadeBase.get_country_by_id(_id);
    }


    @GetMapping("/get_all_countries")
    public ArrayList<CountryPOCO> get_all_countries() {
        FacadeBase facadeBase=new AnonymousFacade();
        return facadeBase.get_all_countries();
    }


    @GetMapping("/get_airline_by_parameters{name}{country_id}")
    public AirlineCompanyPOCO get_airline_by_parameters(@PathVariable String name,@PathVariable int country_id) {
        FacadeBase facadeBase=new AnonymousFacade();
        return facadeBase.get_airline_by_parameters(name,country_id);
    }


    @GetMapping("/get_airline_by_id{id}")
    public AirlineCompanyPOCO get_airline_by_id(@PathVariable long id) {
        FacadeBase facadeBase=new AnonymousFacade();
        return facadeBase.get_airline_by_id(id);
    }


    @GetMapping("/get_all_airlines")
    public ArrayList<AirlineCompanyPOCO> get_all_airlines() {
        FacadeBase facadeBase=new AnonymousFacade();
        return facadeBase.get_all_airlines();
    }


    @GetMapping("/get_flights_by_parameters")
    public ArrayList<FlightPOCO> get_flights_by_parameters(@RequestBody int origin_country_id,
                                                           @RequestBody int destination_country,@RequestBody Timestamp date){
        FacadeBase facadeBase=new AnonymousFacade();
        return facadeBase.get_flights_by_parameters(origin_country_id,destination_country,date);
    }

    @GetMapping("/get_flight_by_id{id}")
    public FlightPOCO get_flight_by_id(@PathVariable long _id) {
        FacadeBase facadeBase=new AnonymousFacade();
        return facadeBase.get_flight_by_id(_id);
    }

    @GetMapping("/get_all_flights")
    public ArrayList<FlightPOCO> get_all_flights() {
        FacadeBase facadeBase=new AnonymousFacade();
        return facadeBase.get_all_flights();
    }

    @GetMapping("/login{username}{password}")
    public FacadeBase login(@PathVariable String username,@PathVariable String password){
        AnonymousFacade anonymousFacade=new AnonymousFacade();
        return anonymousFacade.login(username,password);
    }

    @PostMapping("/register")
    public void register(@RequestBody UserPOCO userPOCO, @RequestBody CustomerPOCO customerPOCO){
        AnonymousFacade anonymousFacade=new AnonymousFacade();
        anonymousFacade.add_customer(userPOCO,customerPOCO);
    }

}
