package com.example.demo.FACEADES;

import com.example.demo.POCOS.*;
import com.example.demo.TOKENS.LoginToken;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
/**
 * This class operates the airlines-allowed functions.
 */
@NoArgsConstructor
public class AirlineFacade extends AnonymousFacade{
    public LoginToken loginToken;

    public AirlineFacade(LoginToken loginToken) {
        this.loginToken = loginToken;
    }

    /**
     * Returns the airline's flights.
     * @return A flightPOCO list of the airline's flights.
     */
        public ArrayList<FlightPOCO> get_my_flights(){
            if(loginToken.getRole()!=2)
                return null;
            return flightDAO.get_flights_by_airline_company(get_airline_by_id(loginToken.getId()));
    }

    /**
     * Update the airline's details(each airline can change only itself).
     * @param airlineCompanyPOCO The airlinePOCO with the changes.
     */
    public void update_airline(AirlineCompanyPOCO airlineCompanyPOCO){
        if(loginToken.getRole()!=2)
            return;
        if(loginToken.getId()==airlineCompanyPOCO.getId())
            airlineCompaniesDAO.Update(airlineCompanyPOCO);
    }

    /**
     * Adds a flight of the airline.
     * @param flightPOCO The flight to add.
     */
    public void add_flight(FlightPOCO flightPOCO){
        if(loginToken.getRole()!=2)
            return;
        if(loginToken.getId()==flightPOCO.getAirline_Company_Id())
            flightDAO.Add(flightPOCO);
    }

    /**
     * Updates a flight(only the flight's airline can make changes in it).
     * @param flightPOCO The flight to change.
     */
    public void update_flight(FlightPOCO flightPOCO){
        if(loginToken.getRole()!=2)
            return;
        if(loginToken.getId()==flightPOCO.getAirline_Company_Id())
            flightDAO.Update(flightPOCO);
    }

    /**
     * Removes a flight(only the flight's airline can remove it).
     * @param flightPOCO The flight to remove.
     */
    public void remove_flight(FlightPOCO flightPOCO){
        if(loginToken.getRole()!=2)
            return;
        if(loginToken.getId()==flightPOCO.getAirline_Company_Id())
            flightDAO.Remove(flightPOCO);
    }

    @Override
    public String toString() {
        return "AirlineFacade{" +
                "loginToken=" + loginToken +
                '}';
    }


}
