package com.example.demo.security;

import com.example.demo.DAOS.UserDAO;
import com.example.demo.POCOS.UserPOCO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.ArrayList;
import java.util.List;

@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    UserDAO userDAO=new UserDAO();
    @Override
    protected  void  configure(HttpSecurity httpSecurity )throws Exception{
        httpSecurity.authorizeHttpRequests()
                .antMatchers("/admin/**").hasRole("ADMIN")
                .antMatchers("/airline/**").hasAnyRole("AIRLINE")
                .antMatchers("/customer/**").hasAnyRole("CUSTOMER")
                .antMatchers("/**").permitAll()
                .and().formLogin();
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth)throws Exception {
        List<UserPOCO> list = new ArrayList<>();
        list = userDAO.GetAll();
        list.stream().forEach(m ->
        {
            try {
                auth
                        .inMemoryAuthentication()
                        .withUser(m.getUsername())
                        .password(m.getPassword())
                        .roles(String.valueOf(m.getUser_Role()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

        @Bean
        public PasswordEncoder getpassEncoder(){
            return NoOpPasswordEncoder.getInstance();
        }

    }

