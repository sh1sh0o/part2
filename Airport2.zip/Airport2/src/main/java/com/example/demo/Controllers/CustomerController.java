package com.example.demo.Controllers;

import com.example.demo.FACEADES.CustomerFacade;
import com.example.demo.POCOS.CustomerPOCO;
import com.example.demo.POCOS.TicketPOCO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    @PutMapping("/")
    public void update(@RequestBody CustomerPOCO customerPOCO){
        CustomerFacade customerFacade=new CustomerFacade();
        customerFacade.update_customer(customerPOCO);
    }

    @PostMapping("/add_ticket")
    public void add_ticket(@RequestBody TicketPOCO ticketPOCO) {
        CustomerFacade customerFacade=new CustomerFacade();
        customerFacade.add_ticket(ticketPOCO);
    }

    @DeleteMapping("/remove_ticket")
    public void remove_ticket(@RequestBody TicketPOCO ticketPOCO){
        CustomerFacade customerFacade=new CustomerFacade();
        customerFacade.remove_ticket(ticketPOCO);
    }

    @GetMapping("/get_my_tickets")
    public ArrayList<TicketPOCO> get_my_tickets(){
        CustomerFacade customerFacade=new CustomerFacade();
        return customerFacade.get_my_tickets();
    }

}