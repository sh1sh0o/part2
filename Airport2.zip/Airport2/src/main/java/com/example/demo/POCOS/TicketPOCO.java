package com.example.demo.POCOS;
/**
 * This class represents a record of "Tickets" table in the database
 */
public class TicketPOCO implements POCO{
    long Id;
    long Flight_Id;
    long Customer_Id;

    public TicketPOCO() {
    }

    public TicketPOCO(long id, long flight_Id, long customer_Id) {
        Id = id;
        Flight_Id = flight_Id;
        Customer_Id = customer_Id;
    }

    public void setId(long id) {
        Id = id;
    }

    public void setFlight_Id(long flight_Id) {
        Flight_Id = flight_Id;
    }

    public void setCustomer_Id(long customer_Id) {
        Customer_Id = customer_Id;
    }

    public long getId() {
        return Id;
    }

    public long getFlight_Id() {
        return Flight_Id;
    }

    public long getCustomer_Id() {
        return Customer_Id;
    }

    @Override
    public String toString() {
        return "TicketPOCO{" +
                "Id=" + Id +
                ", Flight_Id=" + Flight_Id +
                ", Customer_Id=" + Customer_Id +
                '}';
    }
}
