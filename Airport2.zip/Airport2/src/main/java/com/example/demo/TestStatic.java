package com.example.demo;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class TestStatic<T> {
    public static<T> T get(String url,Class<T> tClass){
        HttpClient client= HttpClient
                .newHttpClient();
        HttpRequest request= HttpRequest
                .newBuilder(URI
                        .create(url))
                .build();


        GsonBuilder builder=new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson=builder.create();



        HttpResponse<String> response=null;

        try {
            response= client
                    .send(request,HttpResponse.BodyHandlers.ofString());

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        var stat=response.statusCode();


        var x=gson.fromJson(response.body(),tClass);
        System.out.println(x);
        return x;
    }

    public static int getStutus(String url){
        HttpClient client= HttpClient.newHttpClient();
        HttpRequest request= HttpRequest
                .newBuilder(URI
                        .create(url))
                .build();


        HttpResponse<String> response=null;

        try {
            response= client.send(request,HttpResponse.BodyHandlers.ofString());

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        var stat=response.statusCode();
        return stat;
    }


}
