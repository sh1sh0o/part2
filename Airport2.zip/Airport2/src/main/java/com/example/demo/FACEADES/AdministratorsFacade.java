package com.example.demo.FACEADES;

import com.example.demo.POCOS.*;
import com.example.demo.TOKENS.LoginToken;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
@NoArgsConstructor
public class AdministratorsFacade extends AnonymousFacade{
    public LoginToken loginToken;

    public AdministratorsFacade(LoginToken loginToken) {
        this.loginToken = loginToken;
    }

    /**
     * Returns all the customers.
     * @return All the customers.
     */
    public ArrayList<CustomerPOCO> get_all_customers(){
        if(loginToken.getRole()!=3)
            return null;
        return customerDAO.GetAll();
    }

    /**
     * Creates a new user.
     * @param userPOCO The user to create.
     * @return The created user.
     */
    public UserPOCO create_new_user(UserPOCO userPOCO) {
        if(loginToken.getRole()!=3)
            return null;
        if(userPOCO==null||userPOCO.getPassword().length()<6)
            return null;
        userDAO.Add(userPOCO);
        System.out.println("user created");
        return userPOCO;
    }

    /**
     * Adds an airline-user.
     * @param airlineCompanyPOCO The airline to add.
     * @param userPOCO The airline's user to be.
     */
    public void add_airline(AirlineCompanyPOCO airlineCompanyPOCO,UserPOCO userPOCO){
        if(loginToken.getRole()!=3)
            return ;
            if(airlineCompanyPOCO==null||userPOCO==null)
                return;
            if( airlineCompaniesDAO.Add(airlineCompanyPOCO)) {
                System.out.println("got in");
                //because the given id is by default from the DB
                airlineCompanyPOCO=airlineCompaniesDAO.get_airline_by_parameters(airlineCompanyPOCO.getName(),airlineCompanyPOCO.getCountry_Id());
                System.out.println(airlineCompanyPOCO);
                userPOCO.setId(airlineCompanyPOCO.getId());
                userPOCO.setUser_Role(2);
                userPOCO=create_new_user(userPOCO);
                airlineCompanyPOCO.setUser_Id(userPOCO.getId());
                airlineCompaniesDAO.Update(airlineCompanyPOCO);
                System.out.println("airline created");
            }
    }

    /**
     * Adds an administrator-user.
     * @param administratorPOCO The administrator to add.
     * @param userPOCO The administrator's user to be.
     */
    public void add_administrator(AdministratorPOCO administratorPOCO,UserPOCO userPOCO){
        if(loginToken.getRole()!=3)
            return;
        if(administratorPOCO==null||userPOCO==null)
            return;
        if( administratorDAO.Add(administratorPOCO)) {
            System.out.println("got in");
            //because the given id is by default from the DB
            administratorPOCO=administratorDAO.get_administrator_by_full_name(administratorPOCO.getFirst_Name(),administratorPOCO.getLast_Name());
            System.out.println(administratorPOCO);
            userPOCO.setId(administratorPOCO.getId());
            userPOCO.setUser_Role(3);
            userPOCO=create_new_user(userPOCO);
            administratorPOCO.setUser_Id(userPOCO.getId());
            administratorDAO.Update(administratorPOCO);
            System.out.println("administrator created");
        }
    }

    /**
     * Removes an airline.
     * @param airlineCompanyPOCO The airline to remove.
     */
    public void remove_airline(AirlineCompanyPOCO airlineCompanyPOCO){
        if(loginToken.getRole()!=3)
            return;
        if (airlineCompanyPOCO==null)
            return;
        airlineCompaniesDAO.Remove(airlineCompanyPOCO);
    }

    /**
     * Removes a customer.
     * @param customerPOCO The customer to remove.
     */
    public void remove_customer(CustomerPOCO customerPOCO){
        if(loginToken.getRole()!=3)
            return;
        if (customerPOCO==null)
            return;
        customerDAO.Remove(customerPOCO);
    }

    /**
     * Removes an administrator.
     * @param administratorPOCO The administrator to remove.
     */
    public void remove_administrator(AdministratorPOCO administratorPOCO){
        if(loginToken.getRole()!=3)
            return;
        if (administratorPOCO==null)
            return;
        administratorDAO.Remove(administratorPOCO);
    }

    @Override
    public String toString() {
        return "AdministratorsFacade{" +
                "loginToken=" + loginToken +
                '}';
    }
}
