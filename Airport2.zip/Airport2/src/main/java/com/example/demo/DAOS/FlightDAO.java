package com.example.demo.DAOS;
import com.example.demo.POCOS.*;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
/**
 * This class is being use for interfacing with the "Flights" table in the database
 */
public class FlightDAO implements DAO<FlightPOCO> {
    private PostgresqlConnection connection = new PostgresqlConnection();
    private ArrayList<FlightPOCO> list = new ArrayList<>();
    private String db = "AirPortDB";
    private Connection con = connection.getConnection(db,"791988ss");
    private Statement statement = connection.getStatement();
    DateFormat h= new SimpleDateFormat("yyyy-MM-dd");


    @Override
    public Object Get(long id) {
        FlightPOCO poco = new FlightPOCO();
        try {
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Flights\"\n" +
                    "where \"Flights\".\"Id\"=" + id);
            poco.setId(result.getLong("Id"));
            poco.setAirline_Company_Id(result.getLong("Airline_Company_Id"));
            poco.setOrigin_Country_Id(result.getInt("Origin_country_Id"));
            poco.setDestination_Country_Id(result.getInt("Destination_Country_Id"));
            poco.setDeparture_Time( result.getTimestamp("Departure_Time"));
            poco.setLanding_Time(result.getTimestamp("Landing_Time"));
            poco.setRemaining_Tickets(result.getInt("Remaining_Tickets"));
            result.close();
        } catch (Exception e) {

        }

        return poco;
    }

    @Override
    public ArrayList<FlightPOCO> GetAll() {
        try {
            list.clear();
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Flights\"");
            while (result.next()) {
                FlightPOCO p1 = new FlightPOCO(result.getLong("Id"), result.getLong("Airline_Company_Id")
                        ,result.getInt("Origin_Country_Id"),result.getInt("Destination_Country_Id")
                        , result.getInt("Remaining_Tickets"), result.getTimestamp("Departure_Time"), result.getTimestamp("Landing_Time") );
                list.add(p1);
            }
            result.close();
        } catch (Exception e) {

        }

        return list;
    }

    @Override
    public boolean Add(FlightPOCO o) {
        if(o.getLanding_Time().after(o.getDeparture_Time())){
            System.out.println("Landing time cannot be before departure time");
            return false;
        }
        if(o.getLanding_Time().after(o.getDeparture_Time())){
            System.out.println("Origin country cannot be the same as destination country");
            return false;
        }
        if(o.getRemaining_Tickets()<0) {
            System.out.println("remaining tickets must be positive");
            return false;
        }

        try {
                    statement.executeUpdate("insert into \"Flights\"(\"Airline_Company_Id\",\"Origin_Country_Id\",\n" +
                    "\t\t\t\t\t \"Destination_Country_Id\",\"Remaining_Tickets\",\n" +
                    "\t\t\t\t\t \"Departure_Time\",\"Landing_Time\")" +
                    "values(\n" +
                    o.getAirline_Company_Id() +","+
                    o.getOrigin_Country_Id()+","+
                    o.getDestination_Country_Id()+","+
                    o.getRemaining_Tickets()+","+
                    "\'"+o.getDeparture_Time()+"\'"+","+
                    "\'"+o.getLanding_Time()+"\'"+
                    "\t\n" +
                    ")");
                    return true;
        } catch (Exception e) {
           return false;
        }

    }

    @Override
    public void Remove(FlightPOCO o) {
        if(o==null)
            return;
        try {
            var result = statement.executeUpdate("delete  from \"Flights\"\n" +
                    "where \"Id\"=" + o.getId());
            System.out.println("ok");

        } catch (Exception e) {

        }

    }

    @Override
    public void Update(FlightPOCO o) {
        if(o==null)
            return;

        if(o.getLanding_Time().after(o.getDeparture_Time())){
            System.out.println("Landing time cannot be before departure time");
            return;
        }
        if(o.getLanding_Time().after(o.getDeparture_Time())){
            System.out.println("Origin country cannot be the same as destination country");
            return;
        }
        if(o.getRemaining_Tickets()<0) {
            System.out.println("remaining tickets must be positive");
            return;
        }
        try {
            var result = statement.executeUpdate("UPDATE \"Flights\"\n" +
                    "SET  \"Airline_Company_Id\" =" + o.getAirline_Company_Id()  +
                    ", \"Origin_Country_Id\" =" + o.getOrigin_Country_Id() +" ,\"Destination_Country_Id\" =" + o.getDestination_Country_Id() +
                    ", \"Departure_Time\" =" + "\'"+o.getDeparture_Time()+"\'"+ ", \"Landing_Time\" =" +"\'"+ o.getLanding_Time()+"\'"+
                    ", \"Remaining_Tickets\" =" + o.getRemaining_Tickets()+
                    "where \"Id\"=" + o.getId());
            System.out.println("ok");

        } catch (Exception e) {

        }
    }

    /**
     * Returns a flight POCO list by its origin country id.
     * @param origin_country_id The flight's origin country id.
     * @return a flight POCO list by its origin country id.
     */
    public ArrayList<FlightPOCO> getFlightsByOriginCountryId(int origin_country_id){
        list.clear();
        try {
            ResultSet result = statement.executeQuery("select * from \"Flights\"\n" +
                    "where \"Origin_Country_Id\"="+origin_country_id);
            while(result.next()){
                FlightPOCO p1=new FlightPOCO(result.getLong("Id"),
                      result.getLong("Airline_Company_Id"),
                        result.getInt("Origin_Country_Id"),
                        result.getInt("Destination_Country_Id"),
                        result.getInt("Remaining_Tickets"),
                        result.getTimestamp("Departure_Time"),
                        result.getTimestamp("Landing_Time"));
                list.add(p1);
            }
            result.close();

        } catch (Exception e) {
            System.out.println("fuck");
        }

return list;
    }

    /**
     * Returns a flights POCO list by its destination country id.
     * @param country_id The flight's destination country id.
     * @return a flights POCO list by its destination country id.
     */
   public ArrayList<FlightPOCO> getFlightsByDestinationCountryId(int country_id){
        list.clear();
       try {
           ResultSet result= statement.executeQuery("select * from \"Flights\"\n" +
                   "where \"Destination_Country_Id\"="+country_id);
           while(result.next()){
               FlightPOCO p1=new FlightPOCO(result.getLong("Id"),
                       result.getLong("Airline_Company_Id"),
                       result.getInt("Origin_Country_Id"),
                       result.getInt("Destination_Country_Id"),
                       result.getInt("Remaining_Tickets"),
                       result.getTimestamp("Departure_Time"),
                       result.getTimestamp("Landing_Time"));
               list.add(p1);
           }
           result.close();
       } catch (Exception e) {
           e.printStackTrace();
       }
       return list;
   }

    /**
     * Returns a flight POCO list by its departure time.
     * @param date The flight's departure date.
     * @return a flight POCO list by its departure time.
     */
    public ArrayList<FlightPOCO> getFlightsByDepartureDate(Timestamp date){
        list.clear();
        try {
            ResultSet result= statement.executeQuery("select * from \"Flights\"\n" +
                    "where date(\"Departure_Time\")="+"\'"+h.format(date)+"\'");
            while(result.next()){
                FlightPOCO p1=new FlightPOCO(result.getLong("Id"),
                        result.getLong("Airline_Company_Id"),
                        result.getInt("Origin_Country_Id"),
                        result.getInt("Destination_Country_Id"),
                        result.getInt("Remaining_Tickets"),
                        result.getTimestamp("Departure_Time"),
                        result.getTimestamp("Landing_Time"));
                list.add(p1);
            }
            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Returns a flight POCO list by its landing time.
     * @param date The flight's landing date.
     * @return a flight POCO list by its landing time.
     */
    public ArrayList<FlightPOCO> getFlightsByLandingDate(Timestamp date){
        list.clear();
        try {
            ResultSet result= statement.executeQuery("select * from \"Flights\"\n" +
                    "where date(\"Landing_Time\")="+"\'"+h.format(date)+"\'");
            while(result.next()){
                FlightPOCO p1=new FlightPOCO(result.getLong("Id"),
                        result.getLong("Airline_Company_Id"),
                        result.getInt("Origin_Country_Id"),
                        result.getInt("Destination_Country_Id"),
                        result.getInt("Remaining_Tickets"),
                        result.getTimestamp("Departure_Time"),
                        result.getTimestamp("Landing_Time"));
                list.add(p1);
            }
            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;

    }

    /**
     * Returns a flight POCO list of a customer.
     * @param customer The Flight's customer.
     * @return a flight POCO list of a customer.
     */
    public ArrayList<FlightPOCO> getFlightsByCustomer(CustomerPOCO customer){
        list.clear();
        try {
            var result=statement.executeQuery("select \"Flight_Id\"\n" +
                    "from \"get_tickets_by_customer\"("+customer.getId()+")");
            while(result.next()){
                var result2=statement.executeQuery("select * from \"Flights\"\n" +
                        "where \"Id\"="+result.getInt("Flight_Id"));
                result2.next();
                FlightPOCO p1=new FlightPOCO(result2.getLong("Id"),
                        result2.getLong("Airline_Company_Id"),
                        result2.getInt("Origin_Country_Id"),
                        result2.getInt("Destination_Country_Id"),
                        result2.getInt("Remaining_Tickets"),
                        result2.getTimestamp("Departure_Time"),
                        result2.getTimestamp("Landing_Time"));
                list.add(p1);
                result2.close();
            }
            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Returns a Flight POCO list by its origin_country_id, destination_country and date.
     * @param origin_country_id The flight's origin country id.
     * @param destination_country The flight's destination country id.
     * @param date The flights date.
     * @return a Flight POCO list by its origin_country_id, destination_country and date.
     */
    public ArrayList<FlightPOCO> get_flights_by_parameters(int origin_country_id,
                                                           int destination_country,Timestamp date){
        ArrayList<FlightPOCO> list1=new ArrayList<>();
        try {
            var result=statement.executeQuery("select * from \"get_flights_by_parameters\"(\n" +
                    ""+origin_country_id+","+destination_country+",date(\'"+date+"\')\n" +
                    ")");
            while (result.next()) {
                FlightPOCO poco = new FlightPOCO();
                poco.setId(result.getLong("Id"));
                poco.setAirline_Company_Id(result.getLong("Airline_Company_Id"));
                poco.setOrigin_Country_Id(result.getInt("Origin_country_Id"));
                poco.setDestination_Country_Id(result.getInt("Destination_Country_Id"));
                poco.setDeparture_Time(result.getTimestamp("Departure_Time"));
                poco.setLanding_Time(result.getTimestamp("Landing_Time"));
                poco.setRemaining_Tickets(result.getInt("Remaining_Tickets"));
                list1.add(poco);
            }
            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return  list1;
    }

    /**
     * Returns a flight POCO list of flights whom depart in the next 12 hours in the country.
     * @param country_id The country id of the wanted country.
     * @return a flight POCO list of flights whom depart in the next 12 hours in the country.
     */
    public ArrayList<FlightPOCO> get_departure_flights(int country_id){
        ArrayList<FlightPOCO> list1=new ArrayList<>();
        try {
            var result=statement.executeQuery("select * from \"get_departure_flights\"("+country_id+")");
            while (result.next()){
                FlightPOCO poco=new FlightPOCO();
                poco.setId(result.getLong("Id"));
                poco.setAirline_Company_Id(result.getLong("Airline_Company_Id"));
                poco.setOrigin_Country_Id(result.getInt("Origin_country_Id"));
                poco.setDestination_Country_Id(result.getInt("Destination_Country_Id"));
                poco.setDeparture_Time(result.getTimestamp("Departure_Time"));
                poco.setLanding_Time(result.getTimestamp("Landing_Time"));
                poco.setRemaining_Tickets(result.getInt("Remaining_Tickets"));
                list1.add(poco);
            }
            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list1;
    }

    /**
     * Returns a flight POCO list of flights whom land in the next 12 hours in the country.
     * @param country_id The country id of the wanted country.
     * @return a flight POCO list of flights whom land in the next 12 hours in the country.
     */
    public ArrayList<FlightPOCO> get_arrival_flights(int country_id){
        ArrayList<FlightPOCO> list1=new ArrayList<>();
        try {
            var result=statement.executeQuery("select * from \"get_arrival_flights\"("+country_id+")");
            while (result.next()){
                FlightPOCO poco=new FlightPOCO();
                poco.setId(result.getLong("Id"));
                poco.setAirline_Company_Id(result.getLong("Airline_Company_Id"));
                poco.setOrigin_Country_Id(result.getInt("Origin_country_Id"));
                poco.setDestination_Country_Id(result.getInt("Destination_Country_Id"));
                poco.setDeparture_Time(result.getTimestamp("Departure_Time"));
                poco.setLanding_Time(result.getTimestamp("Landing_Time"));
                poco.setRemaining_Tickets(result.getInt("Remaining_Tickets"));
                list1.add(poco);
            }
            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list1;
    }

    /**
     * Returns a flight POCO list of all the flights of an airline company.
     * @param airlineCompanyPOCO The wanted airline.
     * @return a flight POCO list of all the flights of an airline company.
     */
    public ArrayList<FlightPOCO> get_flights_by_airline_company(AirlineCompanyPOCO airlineCompanyPOCO) {
        ArrayList<FlightPOCO> list1=new ArrayList<>();
        try {
            var result=statement.executeQuery("select * from \"Flights\"\n" +
                    "where \"Airline_Company_Id\"="+airlineCompanyPOCO.getId());
            while (result.next()){
                FlightPOCO poco=new FlightPOCO();
                poco.setId(result.getLong("Id"));
                poco.setAirline_Company_Id(result.getLong("Airline_Company_Id"));
                poco.setOrigin_Country_Id(result.getInt("Origin_country_Id"));
                poco.setDestination_Country_Id(result.getInt("Destination_Country_Id"));
                poco.setDeparture_Time(result.getTimestamp("Departure_Time"));
                poco.setLanding_Time(result.getTimestamp("Landing_Time"));
                poco.setRemaining_Tickets(result.getInt("Remaining_Tickets"));
                list1.add(poco);
            }
            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list1;
    }

    /**
     * Updates the remaining tickets in a flight.
     * @param poco The flight to change.
     * @param change The wanted change(-1 to reduce a ticket from the remaining, +1 to add a ticket to the remaining).
     * @return True if the update succeeded.
     */
    public boolean update_remaining_tickets(FlightPOCO poco,int change){
        if(change==-1){
            if(poco.getRemaining_Tickets()<=0)
                return false;
            else {
                poco.setRemaining_Tickets(poco.getRemaining_Tickets()-1);
                Update(poco);
                return true;
            }
        }else if(change==+1){
            poco.setRemaining_Tickets(poco.getRemaining_Tickets()+1);
            return true;
        }else
            return false;
    }

}





