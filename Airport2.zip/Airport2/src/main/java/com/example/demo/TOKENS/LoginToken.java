package com.example.demo.TOKENS;

/**
 * This class represents the permissions of a user.
 */
public record LoginToken(long id, String name, int role) {

    @Override
    public String toString() {
        return "LoginToken{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", role=" + role +
                '}';
    }

    public long getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public int getRole() {
        return role;
    }
}
