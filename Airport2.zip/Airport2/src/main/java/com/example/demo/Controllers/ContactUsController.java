package com.example.demo.Controllers;

import com.example.demo.DTO.ContactUs;
import com.example.demo.DTO.ContactUsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/contactus")
public class ContactUsController {
    @Autowired
    ContactUsService contactUsService;

    @PostMapping("/")
    public void add(@RequestBody ContactUs contactUs){
        contactUsService.addContactUs(contactUs);
    }

}
