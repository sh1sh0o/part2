package com.example.demo.DAOS;


import com.example.demo.POCOS.AirlineCompanyPOCO;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
/**
 * This class is being use for interfacing with the "Airline_Companies" table in the database
 */

public class AirlineCompaniesDAO implements DAO<AirlineCompanyPOCO> {
    private PostgresqlConnection connection = new PostgresqlConnection();
    private ArrayList<AirlineCompanyPOCO> list = new ArrayList<>();
    private String db = "AirPortDB";
    private Connection con = connection.getConnection(db,"791988ss");
    private Statement statement = connection.getStatement();


    @Override
    public Object Get(long id) {
        AirlineCompanyPOCO poco = new AirlineCompanyPOCO();
        try {
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Airline_Companies\"\n" +
                    "where \"Airline_Companies\".\"Id\"=" + id);
            result.next();
            poco.setId(result.getLong("Id"));
            poco.setCountry_Id(result.getInt("Country_Id"));
            poco.setName(result.getString("Name"));
            poco.setUser_Id(result.getLong("UserId"));
            result.close();
        } catch (Exception e) {

        }

        return poco;
    }

    @Override
    public ArrayList<AirlineCompanyPOCO> GetAll() {
        try {
            list.clear();
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Airline_Companies\"");
            while (result.next()) {
                AirlineCompanyPOCO p1 = new AirlineCompanyPOCO(result.getInt("Id"), result.getString("Name"), result.getInt("Country_Id"), result.getLong("User_Id"));
                list.add(p1);
            }
            result.close();
        } catch (Exception e) {

        }

        return list;
    }

    @Override
    public boolean Add(AirlineCompanyPOCO o) {

        try {
            var result = statement.executeUpdate("insert into \"Airline_Companies\"(\"Name\",\n" +
                    "\"Country_Id\")\n" +
                    "values(\n" +
                    "\'"+o.getName()+"\'" + "," +
                    o.getCountry_Id() +
                    "\t\n" +
                    ")");
            return true;
        } catch (Exception e) {
            System.out.println("error- add airline");
            e.printStackTrace();
return false;
        }
    }

    @Override
    public void Remove(AirlineCompanyPOCO o) {
        if(o==null)
            return;
        try {
            var result = statement.executeUpdate("delete  from \"Airline_Companies\"\n" +
                    "where \"Id\"=" + o.getId());

        } catch (Exception e) {

        }
    }

    @Override
    public void Update(AirlineCompanyPOCO o) {
        if(o==null){
            return;}
        try {
            var result = statement.executeUpdate("UPDATE \"Airline_Companies\"\n"+
                    "set \"Name\" =" + "\'"+o.getName()+"\'" + ",\n" +
                    "\"Country_Id\"=" + o.getCountry_Id() + ",\"User_Id\"=" + o.getUser_Id() + "\n" +
                    "where \"Id\"=" + o.getId());

        } catch (Exception e) {
            System.out.println("error- update airline");
            e.printStackTrace();
        }
    }
    ArrayList<AirlineCompanyPOCO> getAirlinesByCountry(long country_id){

        try {
list.clear();

            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Airline_Companies\"\n" +
                    "where \"Airline_Companies\".\"Country_Id\"="+country_id);

            while (result.next()) {
                AirlineCompanyPOCO p1 = new AirlineCompanyPOCO(result.getInt("Id"), result.getString("Name"), result.getInt("Country_Id"), result.getLong("User_Id"));
                list.add(p1);
            }
            result.close();
        } catch (Exception e) {

        }
        return list;
    }

    /**
     * Returns an airline POCO by its username.
     * @param username The airline's username.
     * @return an airline POCO by its username.
     */
    public AirlineCompanyPOCO get_airline_by_username(String username){
        AirlineCompanyPOCO p1=new AirlineCompanyPOCO();
        try {
            var result= statement.executeQuery("select * from \"get_airline_by_username\"(\'"+username+"\')");
            result.next();
            p1.setId(result.getLong("Id"));
            p1.setName(result.getString("Name"));
            p1.setCountry_Id(result.getInt("Country_Id"));
            p1.setUser_Id(result.getLong("User_Id"));

            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return p1;
    }

    /**
     * Returns an airline POCO by its name and country.
     * @param name The airline's name.
     * @param country_id The airline's country id.
     * @return an airline POCO by its name and country.
     */
    public AirlineCompanyPOCO get_airline_by_parameters(String name, int country_id) {
        AirlineCompanyPOCO poco=new AirlineCompanyPOCO();
        try {
            var result=statement.executeQuery("select * from \"Airline_Companies\"\n" +
                    "where \"Name\"=\'"+name+"\'\n" +
                    "and \"Country_Id\"="+country_id);
            result.next();
            poco.setId(result.getLong("Id"));
            poco.setCountry_Id(result.getInt("Country_Id"));
            poco.setName(result.getString("Name"));
            poco.setUser_Id(result.getLong("User_Id"));
            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }


        return poco;
    }


}
