package com.example.demo.POCOS;

/**
 * This class represents a record of "Administrators" table in the database
 */
public class AdministratorPOCO implements POCO{
   int Id;
   String First_Name;
   String Last_Name;
   long User_Id;

    public void setId(int id) {
        Id = id;
    }

    public void setFirst_Name(String first_Name) {
        First_Name = first_Name;
    }

    public void setLast_Name(String last_Name) {
        Last_Name = last_Name;
    }

    public void setUser_Id(long user_Id) {
        User_Id = user_Id;
    }

    public int getId() {
        return Id;
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public long getUser_Id() {
        return User_Id;
    }

    @Override
    public String toString() {
        return "AdministratorPOCO{" +
                "Id=" + Id +
                ", First_Name='" + First_Name + '\'' +
                ", Last_Name='" + Last_Name + '\'' +
                ", User_Id=" + User_Id +
                '}';
    }

    public AdministratorPOCO() {
    }

    public AdministratorPOCO(int id, String first_Name, String last_Name, long user_Id) {
        Id = id;
        First_Name = first_Name;
        Last_Name = last_Name;
        User_Id = user_Id;
    }
}
