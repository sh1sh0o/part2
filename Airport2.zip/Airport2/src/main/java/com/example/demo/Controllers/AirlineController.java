package com.example.demo.Controllers;

import com.example.demo.FACEADES.AirlineFacade;
import com.example.demo.POCOS.AirlineCompanyPOCO;
import com.example.demo.POCOS.FlightPOCO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/airline")
public class AirlineController {



    @GetMapping("/get_my_flights")
    public ArrayList<FlightPOCO> get_my_flights(){
        AirlineFacade airlineFacade=new AirlineFacade();
       return airlineFacade.get_my_flights();
    }

    @PutMapping("/update_airline")
    public void update_airline(@RequestBody AirlineCompanyPOCO airlineCompanyPOCO){
        AirlineFacade airlineFacade=new AirlineFacade();
        airlineFacade.update_airline(airlineCompanyPOCO);
    }

    @PostMapping("/add_flight")
    public void add_flight(@RequestBody FlightPOCO flightPOCO){
        AirlineFacade airlineFacade=new AirlineFacade();
        airlineFacade.add_flight(flightPOCO);
    }

    @PutMapping("/update_flight")
    public void update_flight(@RequestBody FlightPOCO flightPOCO){
        AirlineFacade airlineFacade=new AirlineFacade();
        airlineFacade.update_flight(flightPOCO);
    }

    @PutMapping("/remove_flight")
    public void remove_flight(@RequestBody FlightPOCO flightPOCO){
        AirlineFacade airlineFacade=new AirlineFacade();
        airlineFacade.remove_flight(flightPOCO);
    }


}
